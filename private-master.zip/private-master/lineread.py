import string
fhand = open("ML_algo.txt","r")
char_count = 0
line_count = 0
dic = {}
for line in fhand:
    line = line.translate(line.maketrans("","",string.punctuation))
    line = line.lower()
    line_count += len(line)
    for words in line.split():
        dic[words] = dic.get(words,0)+1
        pass
    pass
fhand.close()
print("the number of lines in the file",line_count)
print("number of charecter i the file",char_count)
print(dic," is the word frequency")
