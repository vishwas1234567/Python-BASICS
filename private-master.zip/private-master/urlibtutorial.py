import urllib.request
import urllib.parse
x = urllib.request.urlopen('http://www.google.co.in')
print(x.read())
