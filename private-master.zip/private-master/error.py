Python 3.6.7 (default, Oct 22 2018, 11:32:17) 
[GCC 8.2.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
>>> x
array([['France', 44.0, 72000.0],
       ['Spain', 27.0, 48000.0],
       ['Germany', 30.0, 54000.0],
       ['Spain', 38.0, 61000.0],
       ['Germany', 40.0, nan],
       ['France', 35.0, 58000.0],
       ['Spain', nan, 52000.0],
       ['France', 48.0, 79000.0],
       ['Germany', 50.0, 83000.0],
       ['France', 37.0, 67000.0]], dtype=object)
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
>>> y
array(['No', 'Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes'],
      dtype=object)
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
>>> x
array([['France', 44.0, 72000.0],
       ['Spain', 27.0, 48000.0],
       ['Germany', 30.0, 54000.0],
       ['Spain', 38.0, 61000.0],
       ['Germany', 40.0, nan],
       ['France', 35.0, 58000.0],
       ['Spain', nan, 52000.0],
       ['France', 48.0, 79000.0],
       ['Germany', 50.0, 83000.0],
       ['France', 37.0, 67000.0]], dtype=object)
>>> y
array(['No', 'Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes'],
      dtype=object)
>>> from sklearn.preprocessing import Imputer
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 13, in <module>
    imputer = Imputer(missing_values = 'NaN',stratergy = 'mean',axis =0)
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 59, in wrapped
    return init(*args, **kwargs)
TypeError: __init__() got an unexpected keyword argument 'stratergy'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 12, in <module>
    from sklear import SimpleImputer
ModuleNotFoundError: No module named 'sklear'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 12, in <module>
    from sklearn import SimpleImputer
ImportError: cannot import name 'SimpleImputer'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 12, in <module>
    import impute.SimpleImputer
ModuleNotFoundError: No module named 'impute'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 12, in <module>
    import SimpleImputer
ModuleNotFoundError: No module named 'SimpleImputer'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 12, in <module>
    from sklearn.preprocessing import SimpleImputer
ImportError: cannot import name 'SimpleImputer'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 14, in <module>
    imputer = Imputer(missing_values = 'NaN',stratergy = 'mean',axis =0)
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 59, in wrapped
    return init(*args, **kwargs)
TypeError: __init__() got an unexpected keyword argument 'stratergy'
>>> 
from sklearn.preprocessing import Imputer
>>> from sklearn.preprocessing import Imputer

>>> 
KeyboardInterrupt
>>> 
=============================== RESTART: Shell ===============================
>>> from sklearn.preprocessing import Imputer

>>> 
>>> imputer = Imputer(missing_values = 'NaN',stratergy = 'mean',axis =0)


Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    imputer = Imputer(missing_values = 'NaN',stratergy = 'mean',axis =0)
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 59, in wrapped
    return init(*args, **kwargs)
TypeError: __init__() got an unexpected keyword argument 'stratergy'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> x
array([['France', 44.0, 72000.0],
       ['Spain', 27.0, 48000.0],
       ['Germany', 30.0, 54000.0],
       ['Spain', 38.0, 61000.0],
       ['Germany', 40.0, 63777.77777777778],
       ['France', 35.0, 58000.0],
       ['Spain', 38.77777777777778, 52000.0],
       ['France', 48.0, 79000.0],
       ['Germany', 50.0, 83000.0],
       ['France', 37.0, 67000.0]], dtype=object)
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 10, in <module>
    from skearn import SimpleImputer
ModuleNotFoundError: No module named 'skearn'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 10, in <module>
    from sklearn import SimpleImputer
ImportError: cannot import name 'SimpleImputer'
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> x
array([['France', 44.0, 72000.0],
       ['Spain', 27.0, 48000.0],
       ['Germany', 30.0, 54000.0],
       ['Spain', 38.0, 61000.0],
       ['Germany', 40.0, 61000.0],
       ['France', 35.0, 58000.0],
       ['Spain', 38.0, 52000.0],
       ['France', 48.0, 79000.0],
       ['Germany', 50.0, 83000.0],
       ['France', 37.0, 67000.0]], dtype=object)
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> x
array([['France', 44.0, 72000.0],
       ['Spain', 27.0, 48000.0],
       ['Germany', 30.0, 54000.0],
       ['Spain', 38.0, 61000.0],
       ['Germany', 40.0, 48000.0],
       ['France', 35.0, 58000.0],
       ['Spain', 27.0, 52000.0],
       ['France', 48.0, 79000.0],
       ['Germany', 50.0, 83000.0],
       ['France', 37.0, 67000.0]], dtype=object)
>>> from sklearn.preprocessing import LabelEncoder
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 22, in <module>
    a[:,0] = labelencoder_x.fit_transform(x[:,0])
NameError: name 'a' is not defined
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> x
array([[0, 44.0, 72000.0],
       [2, 27.0, 48000.0],
       [1, 30.0, 54000.0],
       [2, 38.0, 61000.0],
       [1, 40.0, 48000.0],
       [0, 35.0, 58000.0],
       [2, 27.0, 52000.0],
       [0, 48.0, 79000.0],
       [1, 50.0, 83000.0],
       [0, 37.0, 67000.0]], dtype=object)
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.
>>> x
array([[0, 44.0, 72000.0],
       [2, 27.0, 48000.0],
       [1, 30.0, 54000.0],
       [2, 38.0, 61000.0],
       [1, 40.0, 48000.0],
       [0, 35.0, 58000.0],
       [2, 27.0, 52000.0],
       [0, 48.0, 79000.0],
       [1, 50.0, 83000.0],
       [0, 37.0, 67000.0]], dtype=object)
>>> 
Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.

 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
>>> import cv2
>>> cap = cv2.VideoCapture(0)
>>> ret ,frame   = cap.release()
Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    ret ,frame   = cap.release()
TypeError: 'NoneType' object is not iterable
>>> a = cap.release()
>>> cv2.imshow("a",a)
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    cv2.imshow("a",a)
cv2.error: OpenCV(4.1.0) /io/opencv/modules/highgui/src/window.cpp:352: error: (-215:Assertion failed) size.width>0 && size.height>0 in function 'imshow'

>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
>>> x
array([[1., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0.,
        0., 0., 1., 0., 0.],
       [0., 0., 1., 1., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0.,
        0., 0., 0., 0., 0.],
       [0., 1., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0.,
        0., 0., 0., 0., 0.],
       [0., 0., 1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0.,
        1., 0., 0., 0., 0.],
       [0., 1., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 1., 0., 0., 0.,
        0., 0., 0., 0., 0.],
       [1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1.,
        0., 0., 0., 0., 0.],
       [0., 0., 1., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0.,
        0., 0., 0., 0., 0.],
       [1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0.,
        0., 0., 0., 1., 0.],
       [0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0.,
        0., 0., 0., 0., 1.],
       [1., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
        0., 1., 0., 0., 0.]])
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 28, in <module>
    y[:,0] = labelencoder_x.fit_transform(y[:,0])
IndexError: too many indices for array
>>> y

=============================== RESTART: Shell ===============================
>>> y
Traceback (most recent call last):
  File "<pyshell#23>", line 1, in <module>
    y
NameError: name 'y' is not defined
>>> x
Traceback (most recent call last):
  File "<pyshell#24>", line 1, in <module>
    x
NameError: name 'x' is not defined
>>> x
Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    x
NameError: name 'x' is not defined
>>> x
Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    x
NameError: name 'x' is not defined
x
>>> 
x
>>> 
>>> x
Traceback (most recent call last):
x  File "<pyshell#29>", line 1, in <module>
    x
NameError: name 'x' is not defined
>>> 
>>> x
Traceback (most recent call last):
  File "<pyshell#31>", line 1, in <module>
    x
NameError: name 'x' is not defined
>>> 
 RESTART: /home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py 

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/utils/deprecation.py", line 58
    warnings.warn(msg, category=DeprecationWarning)
DeprecationWarning: Class Imputer is deprecated; Imputer was deprecated in version 0.20 and will be removed in 0.22. Import impute.SimpleImputer from sklearn instead.

Warning (from warnings module):
  File "/home/vishwasnarayan/.local/lib/python3.6/site-packages/sklearn/preprocessing/_encoders.py", line 371
    warnings.warn(msg, FutureWarning)
FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
If you want the future behaviour and silence this warning, you can specify "categories='auto'".
In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/machienelearning a to z/P14-Machine-Learning-AZ-Template-Folder/Machine Learning A-Z Template Folder/Part 1 - Data Preprocessing/datapreprocessingtemplate.py", line 28, in <module>
    y[:,0] = labelencoder_y.fit_transform(y[:,0])
IndexError: too many indices for array
>>> x
array([[1., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0.,
        0., 0., 1., 0., 0.],
       [0., 0., 1., 1., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0.,
        0., 0., 0., 0., 0.],
       [0., 1., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0.,
        0., 0., 0., 0., 0.],
       [0., 0., 1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0.,
        1., 0., 0., 0., 0.],
       [0., 1., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 1., 0., 0., 0.,
        0., 0., 0., 0., 0.],
       [1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1.,
        0., 0., 0., 0., 0.],
       [0., 0., 1., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0.,
        0., 0., 0., 0., 0.],
       [1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0.,
        0., 0., 0., 1., 0.],
       [0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0.,
        0., 0., 0., 0., 1.],
       [1., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
        0., 1., 0., 0., 0.]])
>>> y
array(['No', 'Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes'],
      dtype=object)
>>> import cv2
>>> 
====== RESTART: /home/vishwasnarayan/Documents/python/urlibtutorial.py ======
Traceback (most recent call last):
  File "/usr/lib/python3.6/urllib/request.py", line 1318, in do_open
    encode_chunked=req.has_header('Transfer-encoding'))
  File "/usr/lib/python3.6/http/client.py", line 1239, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1285, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1234, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1026, in _send_output
    self.send(msg)
  File "/usr/lib/python3.6/http/client.py", line 964, in send
    self.connect()
  File "/usr/lib/python3.6/http/client.py", line 936, in connect
    (self.host,self.port), self.timeout, self.source_address)
  File "/usr/lib/python3.6/socket.py", line 704, in create_connection
    for res in getaddrinfo(host, port, 0, SOCK_STREAM):
  File "/usr/lib/python3.6/socket.py", line 745, in getaddrinfo
    for res in _socket.getaddrinfo(host, port, family, type, proto, flags):
socket.gaierror: [Errno -3] Temporary failure in name resolution

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/python/urlibtutorial.py", line 2, in <module>
    x = urllib.request.urlopen('http://www.google.co.in')
  File "/usr/lib/python3.6/urllib/request.py", line 223, in urlopen
    return opener.open(url, data, timeout)
  File "/usr/lib/python3.6/urllib/request.py", line 526, in open
    response = self._open(req, data)
  File "/usr/lib/python3.6/urllib/request.py", line 544, in _open
    '_open', req)
  File "/usr/lib/python3.6/urllib/request.py", line 504, in _call_chain
    result = func(*args)
  File "/usr/lib/python3.6/urllib/request.py", line 1346, in http_open
    return self.do_open(http.client.HTTPConnection, req)
  File "/usr/lib/python3.6/urllib/request.py", line 1320, in do_open
    raise URLError(err)
urllib.error.URLError: <urlopen error [Errno -3] Temporary failure in name resolution>
>>> 
====== RESTART: /home/vishwasnarayan/Documents/python/urlibtutorial.py ======
Traceback (most recent call last):
  File "/usr/lib/python3.6/urllib/request.py", line 1318, in do_open
    encode_chunked=req.has_header('Transfer-encoding'))
  File "/usr/lib/python3.6/http/client.py", line 1239, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1285, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1234, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1026, in _send_output
    self.send(msg)
  File "/usr/lib/python3.6/http/client.py", line 964, in send
    self.connect()
  File "/usr/lib/python3.6/http/client.py", line 936, in connect
    (self.host,self.port), self.timeout, self.source_address)
  File "/usr/lib/python3.6/socket.py", line 704, in create_connection
    for res in getaddrinfo(host, port, 0, SOCK_STREAM):
  File "/usr/lib/python3.6/socket.py", line 745, in getaddrinfo
    for res in _socket.getaddrinfo(host, port, family, type, proto, flags):
socket.gaierror: [Errno -3] Temporary failure in name resolution

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/python/urlibtutorial.py", line 2, in <module>
    x = urllib.request.urlopen('http://www.google.co.in')
  File "/usr/lib/python3.6/urllib/request.py", line 223, in urlopen
    return opener.open(url, data, timeout)
  File "/usr/lib/python3.6/urllib/request.py", line 526, in open
    response = self._open(req, data)
  File "/usr/lib/python3.6/urllib/request.py", line 544, in _open
    '_open', req)
  File "/usr/lib/python3.6/urllib/request.py", line 504, in _call_chain
    result = func(*args)
  File "/usr/lib/python3.6/urllib/request.py", line 1346, in http_open
    return self.do_open(http.client.HTTPConnection, req)
  File "/usr/lib/python3.6/urllib/request.py", line 1320, in do_open
    raise URLError(err)
urllib.error.URLError: <urlopen error [Errno -3] Temporary failure in name resolution>
>>> 
====== RESTART: /home/vishwasnarayan/Documents/python/urlibtutorial.py ======
Traceback (most recent call last):
  File "/usr/lib/python3.6/urllib/request.py", line 1318, in do_open
    encode_chunked=req.has_header('Transfer-encoding'))
  File "/usr/lib/python3.6/http/client.py", line 1239, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1285, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1234, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.6/http/client.py", line 1026, in _send_output
    self.send(msg)
  File "/usr/lib/python3.6/http/client.py", line 964, in send
    self.connect()
  File "/usr/lib/python3.6/http/client.py", line 936, in connect
    (self.host,self.port), self.timeout, self.source_address)
  File "/usr/lib/python3.6/socket.py", line 704, in create_connection
    for res in getaddrinfo(host, port, 0, SOCK_STREAM):
  File "/usr/lib/python3.6/socket.py", line 745, in getaddrinfo
    for res in _socket.getaddrinfo(host, port, family, type, proto, flags):
socket.gaierror: [Errno -3] Temporary failure in name resolution

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/home/vishwasnarayan/Documents/python/urlibtutorial.py", line 2, in <module>
    x = urllib.request.urlopen('http://www.google.co.in')
  File "/usr/lib/python3.6/urllib/request.py", line 223, in urlopen
    return opener.open(url, data, timeout)
  File "/usr/lib/python3.6/urllib/request.py", line 526, in open
    response = self._open(req, data)
  File "/usr/lib/python3.6/urllib/request.py", line 544, in _open
    '_open', req)
  File "/usr/lib/python3.6/urllib/request.py", line 504, in _call_chain
    result = func(*args)
  File "/usr/lib/python3.6/urllib/request.py", line 1346, in http_open
    return self.do_open(http.client.HTTPConnection, req)
  File "/usr/lib/python3.6/urllib/request.py", line 1320, in do_open
    raise URLError(err)
urllib.error.URLError: <urlopen error [Errno -3] Temporary failure in name resolution>
>>> 
