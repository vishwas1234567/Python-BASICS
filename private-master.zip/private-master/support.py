def printf(par):
    print(par)
    return
