file1 = open("Elon_Musk.txt","r")
text = file1.read().split('\n')
print("the first ten lines are")
for lines in text[:10]:
    print(lines)
    pass
print('\n\n')
print("the last ten lines are")
for lines in text[-10:]:
    print(lines)
    
