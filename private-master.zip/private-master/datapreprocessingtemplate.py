#import the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#import data set
#the working directory folder
dataset = pd.read_csv("Data.csv")
x= dataset.iloc[:,:-1].values #the coloums that we will be reading
y = dataset.iloc[:,3].values #the third coloums selsected
#from sklearn import SimpleImputer
#import impute.SimpleImputer from sklearn #showed an error at the from
from sklearn.preprocessing import Imputer
#from sklearn.preprocessing import SimpleImputer
#object for the class
imputer = Imputer(missing_values = 'NaN',strategy = 'most_frequent',axis =0)
#to fit the imputer object to the matrix of the fit value
imputer.fit(x[:,1:3])
#fit(x[:, 1:3])
x[:, 1:3] = imputer.transform(x[:,1:3])
#Encoding the catagorical data
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
labelencoder_x = LabelEncoder()
x[:,0] = labelencoder_x.fit_transform(x[:,0])
#fit_transform(x[:,0])
onehotencoder =OneHotEncoder()
y = onehotencoder.fit_transform(x).toarray()#we add the binary weights
labelencoder_y = LabelEncoder()
y[:,0] = labelencoder_y.fit_transform(y[:,0])

#make the learning for the learnig from the heart the cross vaiadation library
#from sklearn.cross_validation import train_test_split
#x_train ,x_test,y_train,y_test

