import pygame
import random
#the screen size is being set here
width = 300
height = 400
#the speed in the clock.tick will be set in here
white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
pygame.init()
pygame.mixer.init()
screen = display.set_mode((width,height))
pygame.display.set_caption("i am loving it")
clock = pygame.time.Clock() #the clock for the pygame window will be set
running = True #the code to the terminatin of the program for the running the python window
while running:
    clock.tick(fps) #the call from the pygame.time.Clock() function in the call
    for even in pygame.event.get():
        if event.type == pygame.QUIT():
            running = False
            pass
        pass
    screen.fill(white)
    pygame.display.flip()
    pass
pygame.quit()


