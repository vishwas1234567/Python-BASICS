import pygame
import random
White = (255,255,255)
pygame.init()
pygame.mixer.init()
screen = pygame.display.setmode((455,355))
pygame.display.set_caption("the caption")
clock = pygame.time.Clock()
running = True
while running:
      #the code to keep tje code running:  
    for event in pygame.event.get():
        running = False
        if event ==pygame.downArrow():
            running  = True #the program will always be running
    #the fill function for the filling the screen

    screen.fill(White)
    pygame.display,flip()
pygame.quit()
