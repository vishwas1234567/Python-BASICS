import random
random_number = [random.random() for i in range(5)]
print("random number",random_number)
#the result
#random number [0.32795875615144376, 0.7216522267175545, 0.1780265612284605, 0.3535816877023362, 0.7996909593691325]
random.seed(10)
new_random_number = [random.random() for i in range(5)]
print("new_random_number after random.seed(10)",new_random_number)
names = ["vishwas " ,"hima","narayan","pushpa"]
for i in range(10):
    print(random.choice(names))
print("DONE WITH THE RANDOM CHOISE")
print()

