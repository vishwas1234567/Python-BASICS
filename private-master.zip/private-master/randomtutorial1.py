#this shouldent be use in the cryptography
import random
#the ranom and the uniform mehtodd ca be used
#the inclusive and the non inclsive methods can be use din here
cal = random.random()
cal1 = random.uniform(1,19)
print(cal)
print(cal1)
#to get the random integer
value = random.randint(1,6)
print(value)
colors = ['red','green','yellow']
greet = random.choices(colors,weights = [18,18,2] ,k = 10)
print(greet)
#the deck of the cards program
dec = list(range(1,52))
print(dec)
print("after the shuffle operation")
random.shuffle(dec)
print(dec,'\n')
print("the hand smple")
hand = random.sample(dec,k=5)
print(hand)


