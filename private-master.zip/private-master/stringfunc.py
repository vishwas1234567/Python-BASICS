import string
a = "this is funcking awesome"
print(a)
b = a.capitalize()
print(b)
c = "nanyong"
d = c.center(11,"v")
print(d)
print("From 2nd charecter i will traverse")
e = a.count("t",2,len(a))
print(e)
print("from zero i will traverse")
f = a.count("t",0,len(a))
print(f)
print("if the string ends with 'g'")
g = a.endswith("g",0,len(a))
print(g)
print("if the string ends with 'e'")
h = a.endswith("e",0,len(a))#return if the collected caharecter has the ending value as "e" at the last
print(h)
#here the index of the 'o' will be taken into consideration
i = a.find('o',0,len(a))#retruns the index value of the function
print(i)
#the index function that will be defined for the operation
j = a.index("m",0,len(a))
print(j)
k = a.index(a,0,len(a))
print(k)
l = a.islower()
print(l)
m = "KAli"
n = m.islower()
print(n)
o = m.isupper()
print(o)
q = "Hello To The World"
p = q.istitle(a)
print(p)








