#try yout luck
import random
greeting = ['twerk','cake face','hickup','no mustach']#here the sequence will be in the
#list format
that = ['thanks','paint your face','teach me harder','study signals']
greet  = random.choice(greeting)
that = random.choice(that)
print(greet + that)
